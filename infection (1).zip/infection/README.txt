Jeu d'infection - Projet d'Intelligence artificielle et jeux adversariaux (Sécurité et Aide à la décision)
Ahouefa ZOUNON groupe 1B -- "Ahouefa Zounon" <22010454@etu.unicaen.fr>
Malick Sarr GAYE groupe 1A --"Malick Sarr Gaye" <22012276@etu.unicaen.fr>
Steven MARTIN groupe 1B -- "Steven Martin" <21901638@etu.unicaen.fr>

Pour exécuter le programme, il faudra passer en paramètre la profondeur(entier) de chaque player ainsi que "true" ou "false" 
pour préciser si l'on veut utiliser ou pas la version d'élagage. (Dans le terminal et à faire après avoir compiler)
Exemple : java -cp "build" src/infection.Main 5 5 true

Nous avons réalisé le minimax, le negamax et l'alphabeta.
En mettant "false" lors de l'exécution dans le terminal, vous devrez choisir entre le minimax et le negamax en 
entrant 0 (pour le minimax) ou 1 (pour le negamax) quand il vous le sera demandé.

L'attribut listEtats de la classe State permet d'avoir la liste des différents états joués. 
On rajoute à la liste chaque état résultant de l'appel de la méthode play(Move m).
Nous n'avons implémenté ni getter, ni setter pour cet attribut.

Nous n'avons pas implémenté de setter pour l'attribut grille non plus.

Nous avons rajouté certaines méthodes : 
-La méthode getPosA(int x) utilisée par getMove(Player p) dans la classe State
-La méthode same() utilisée par isOver() dans la classe State
-La méthode nbrePoints(Player p) utilisée par la méthode getScore(Player p) dans la classe State
-La méthode toString permet d'afficher un état de jeu
