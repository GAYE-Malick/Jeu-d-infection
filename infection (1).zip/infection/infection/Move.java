package infection;

public class Move {
	
	private int posD; //position de déjà occupée
	private int posA; //position d'arrivée
	
	public Move(int x, int y)
	{
		this.posD = x;
		this.posA = y;
	}
	
//Redéfinition de toString()
	
	@Override
	public String toString() {
		
		int dep = this.posD;
		int arr = this.posA;
		
		int l = dep/7;
		int c = dep-(l*7);
		
		int m = arr/7;
		int n = arr-(m*7);
				
		return "De " + dep + "(" + (l) + "," + (c) + ")" + " à " + arr + "(" + (m) + "," + (n) + ")" + " \n";
	}
	
	
//GETTERS ET SETTERS	

	public Integer getPosD() {
		return this.posD;
	}

	public Integer getPosA() {
		return this.posA;
	}

	public void setPosD(int posD) {
		this.posD = posD;
	}

	public void setPosA(int posA) {
		this.posA = posA;
	}
	
}
