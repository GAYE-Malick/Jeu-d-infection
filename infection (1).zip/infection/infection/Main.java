package infection;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) { 
		// TODO Auto-generated method stub
		
		int n1 = Integer.parseInt(args[0]);
		int n2 = Integer.parseInt(args[1]);
		boolean genre = Boolean.valueOf(args[2]).booleanValue();
		
		Player p;
		Player p1 = new Player("Bleu",n1); 
		Player p2 = new Player("Rouge",n2);
		State game = new State(p1,p2);
		int cpt, entry = 0; //cpt désigne le nombre de noeuds visités -- entry permet de choisir entre le minimax et le negamax
		Scanner sc = new Scanner(System.in);
		
		Move move;
		Minimax minimax = null;
		Negamax negamax = null;
		AlphaBeta alphabeta = null;
		game.toString();
						
		if(genre == false) //On utilise le minmax ou le negamax
		{
			System.out.println("BIENVENUE! \nVous jouez sans la version d'élagage! ");
			System.out.println("Voulez-vous jouer avec le minimax ou le negamax ?");
			do {
				  System.out.println("Entrez 0 pour le Minimax et 1 pour le Negamax.");
				entry = sc.nextInt();
			} while (entry != 0 && entry != 1 );
				
			while(game.isOver() == false)
			{
				p = game.getCurrentPlayer();
				if(entry == 0) 
				{
					minimax = new Minimax(p,p.getProf());
					move = minimax.getBestMove(game);
				}
				else
				{
					negamax = new Negamax(p,p.getProf());
					move = negamax.getBestMove(game);
				}
					
				game = game.play(move);
				game.toString();
			}
		}
		else //On utilise l'alphaBeta
		{
			System.out.println("BIENVENUE! \nVous jouez avec la version d'élagage! ");
			while(game.isOver() == false)
			{
				p = game.getCurrentPlayer();
				alphabeta = new AlphaBeta(p, p.getProf());
				move = alphabeta.getBestMove(game);
					
				game = game.play(move);
				game.toString();
			}
		}
					
		if(game.isOver())
		{
			cpt = (genre == false) ? ( (entry == 0) ? minimax.getCpt() : negamax.getCpt() ) : alphabeta.getCpt(); //Si genre est false alors, le programme a été executé soit avec le minimax soit avec le negamax. S'il est true, c'est plutôt l'alphaBeta qui a été utilisé
			
			System.out.println("Le nombre de noeuds parcourus est: " + cpt + "\nSCORES: " + p1.toString() + " " + game.getScore(p1) + "   " + p2.toString() + " " + game.getScore(p2));
			
			if(game.getScore(p1) > game.getScore(p2)) { System.out.println("Le gagnant est: " + p1.toString()); }
			else if(game.getScore(p1) < game.getScore(p2)) { System.out.println("Le gagnant est: " + p2.toString()); }
			else System.out.println("Match nul!");
		}
		
		sc.close();
	}

}
