package infection;
import java.util.ArrayList;

public class State {

	private Player[][] grille = new Player[7][7];
	private Player p1, p2, currentPlayer;
	private ArrayList<State> listEtats = new ArrayList<State>(); // sert pour la méthode etat et pour la méthode isOver()
	
	public State(Player p1, Player p2)
	{
		this.p1 = p1;
		this.p2 = p2;
		this.currentPlayer = p1;
		
	// Initialisation de la grille de jeu
		this.grille[0][6] = this.p1; // Le p1 est le joueur bleu représenté par des "X"
		this.grille[0][0] = this.p2; // Le p2 est le joueur rouge représenté par des "O"
		this.grille[6][0] = this.p1; // Le p1 est le joueur bleu représenté par des "X"
		this.grille[6][6] = this.p2; // Le p2 est le joueur rouge représenté par des "O"
	}

// METHODES REQUISES
	
// Méthode isOver()
	//Méthode auxiliaire de la méthode isOver()
	private boolean same()
	{
		boolean same = false;
		int fin = 0;
		if( this.listEtats.size() != 0 ) {
			for(int i=0 ; i < this.listEtats.size() ; i++) {
				for(int j=0 ; j < 7 ; j++) {
					for(int k=0 ; k < 7 ; k++) {
						if( this.listEtats.get(i).grille[j][k] == this.grille[j][k] ) fin++;
					}
				}
				if( fin == 49 ) same = true; // fin = 49 si toutes les cases sont identiques.
				if(same == true ) 	break; // Si on a une grille qui est pareille, on arrête la boucle
				fin = 0;
			}
		}
		
		return same;
	}
	
	public boolean isOver() // implémentée pour désigner une fin de partie
	{
		if( (this.getScore(this.p1) == 1.0) || (this.getScore(this.p2) == 1.0) ) { return true; }
		else if( (this.getMove(this.p1).size() == 0) && (this.getMove(this.p2).size() == 0) ) { return true; }
		else if ( this.same() == true ) { return true; }
		else { return false; }
	}
	
// Méthode getMove()
	
	//Méthode auxiliaire de la méthode getMove()
	private ArrayList<Integer> getPosA(int dep)
	{
		ArrayList<Integer> coups = new ArrayList<Integer>();	
		// l et c servent à placer le coup dans la grille.
			int l = dep/7;
			int c = dep-(l*7);
				
		//Ce bloc représente le clonage en fonction des 8 différentes directions
			if(c-1 >= 0) 
			{	
				if( this.grille[l][c-1] == null) { coups.add((c-1)+(l*7)); }  // un pas vers la gauche 
			}
					
			if(c+1 <= 6)
			{
				if( this.grille[l][c+1] == null) { coups.add((c+1)+(l*7)); } //un pas vers la droite
			}
					
			if(l-1 >= 0)
			{
				if( this.grille[l-1][c] == null) { coups.add(c+((l-1)*7)); } //un pas vers le haut
			}
					
			if(l+1 <= 6)
			{
				if( this.grille[l+1][c] == null) { coups.add(c+((l+1)*7)); } //un pas vers le bas
			}
					
			if( (l-1 >= 0) && (c-1 >= 0) )
			{
				if( this.grille[l-1][c-1] == null) { coups.add((c-1)+((l-1)*7)); } //un pas vers le haut sur la diagonale gauche 
			}
					
			if( (l-1 >= 0) && (c+1 <= 6) )
			{
				if( this.grille[l-1][c+1] == null) { coups.add((c+1)+((l-1)*7)); } //un pas vers le haut sur la diagonale droite
			}
					
			if( (l+1 <= 6) && (c-1 >= 0) )
			{
				if( this.grille[l+1][c-1] == null) { coups.add((c-1)+((l+1)*7)); } //un pas vers le bas sur la diagonale gauche
			}
					
			if( (l+1 <= 6) && (c+1 <= 6) )
			{
				if( this.grille[l+1][c+1] == null) { coups.add((c+1)+((l+1)*7)); } //un pas vers le bas sur la diagonale droite
			}
					
		//Ce bloc représente le saut en fonction des 8 différentes directions	
			if(c-2 >= 0) 
			{
				if( this.grille[l][c-2] == null) { coups.add((c-2)+(l*7)); }  /* deux pas vers la gauche */
			}
					
			if(c+2 <= 6)
			{
				if( this.grille[l][c+2] == null) { coups.add((c+2)+(l*7)); } //deux pas vers la droite
			}
					
			if(l-2 >= 0)
			{
				if( this.grille[l-2][c] == null) { coups.add(c+((l-2)*7)); } //deux pas vers le haut
			}
					
			if(l+2 <= 6)
			{
				if( this.grille[l+2][c] == null) { coups.add(c+((l+2)*7)); } //deux pas vers le bas
			}
					
			if( (l-2 >= 0) && (c-2 >= 0) )
			{
				if( this.grille[l-2][c-2] == null) { coups.add((c-2)+((l-2)*7)); } //deux pas vers le haut sur la diagonale gauche 
			}
					
			if( (l-2 >= 0) && (c+2 <= 6) )
			{
				if( this.grille[l-2][c+2] == null) { coups.add((c+2)+((l-2)*7)); } //deux pas vers le haut sur la diagonale droite
			}
					
			if( (l+2 <= 6) && (c-2 >= 0) )
			{
				if( this.grille[l+2][c-2] == null) { coups.add((c-2)+((l+2)*7)); } //deux pas vers le bas sur la diagonale gauche
			}
					
			if( (l+2 <= 6) && (c+2 <= 6) )
			{
				if( this.grille[l+2][c+2] == null) { coups.add((c+2)+((l+2)*7)); } //deux pas vers le bas sur la diagonale droite
			}
						
		return coups;
	}
		
	//Méthode getMove()
		
	public ArrayList<Move> getMove(Player p) // implémentée pour retourner la liste des coups valides pour un player
	{
		//Les différentes positions de départ 
			int m = 0;
			ArrayList<Integer> pions = new ArrayList<Integer>();
			for (int i=0 ; i<7 ; i++ ) {
				for (int j=0 ; j<7 ; j++ ) {
			        if (this.grille[i][j] == p) 
			        {
			        	pions.add(m);
			        }
			      m++;
			    }
			}
			
			ArrayList<Move> move = new ArrayList<Move>();
			
				for (int i=0 ; i<pions.size() ; i++ ) {
					
					ArrayList<Integer> posA = this.getPosA(pions.get(i));
					
					for(int j=0 ; j<posA.size() ; j++) {
						move.add(new Move(pions.get(i),posA.get(j)));
					}
				}
				
		return move;
	}
	
// Méthode getScore()
	//Méthode auxiliaire qui permet de calculer le nombre de pions d'un joueur
	private int nbrePions(Player p)
	{
		int n = 0;
		for (int i=0 ; i<7 ; i++ ) {
			for (int j=0 ; j<7 ; j++ ) {
		        if (this.grille[i][j] == p) { n++; }
		    }
		}
		
		return n;
	}
	
	//Méthode getScore()
	public double getScore(Player p)
	{
		double n = this.nbrePions(p);
		double tot = this.nbrePions(this.p1) + this.nbrePions(this.p2);
		
		return (double) Math.round((n/tot) * 100) / 100;
	}

// Méthode play()	
	public State play(Move move) // retourne un state
	{		
		if(move != null)
		{	
			int dep = move.getPosD(); // dep représente la pos de départ (déjà occupée)
			int arr = move.getPosA(); // arr représente la pos d'arrivée
			
			// l et c servent à placer le coup de départ dans la grille.
				int l = dep/7;
				int c = dep-(l*7);
				
			// m et n servent à placer le coup d'arrivée dans la grille.
				int m = arr/7;
				int n = arr-(m*7);
				
				int len = Math.abs(m-l) + Math.abs(n-c);
				
				if(len == 2) { this.grille[l][c] = null; } // Si la distance entre les deux positions est égale à 2, c'est qu'il s'agit d'un saut. Donc on on retire le pion de la case de départ.
				
				this.grille[m][n] = this.currentPlayer;
				
			//Ce bloc représente l'infection dans les 8 différentes directions	
				if(n-1 >= 0)
				{
					if(this.grille[m][n-1] != this.currentPlayer)
					this.grille[m][n-1] = this.currentPlayer; //un pas vers la gauche
				}
				
				if(n+1 <= 6)
				{
					if(this.grille[m][n+1] != this.currentPlayer)
					this.grille[m][n+1] = this.currentPlayer; //un pas vers la droite
				}
				
				if(m-1 >= 0)
				{
					if(this.grille[m-1][n] != this.currentPlayer)
					this.grille[m-1][n] = this.currentPlayer; //un pas vers le haut
				}
				
				if(m+1 <= 6)
				{
					if(this.grille[m+1][n] != this.currentPlayer)
					this.grille[m+1][n] = this.currentPlayer; //un pas vers le bas
				}
				
				if( (m-1 >= 0) && (n-1 >= 0) )
				{
					if(this.grille[m-1][n-1] != this.currentPlayer)
					this.grille[m-1][n-1] = this.currentPlayer; //un pas vers le haut sur la diagonale gauche
				}
				
				if( (m-1 >= 0) && (n+1 <= 6) )
				{
					if(this.grille[m-1][n+1] != this.currentPlayer)
					this.grille[m-1][n+1] = this.currentPlayer; //un pas vers le haut sur la diagonale droite
				}
				
				if( (m+1 <= 6) && (n-1 >= 0) )
				{
					if(this.grille[m+1][n-1] != this.currentPlayer)
					this.grille[m+1][n-1] = this.currentPlayer; //un pas vers le bas sur la diagonale gauche
				}
				
				if( (m+1 <= 6) && (n+1 <= 6) )
				{
					if(this.grille[m+1][n+1] != this.currentPlayer)
					this.grille[m+1][n+1] = this.currentPlayer; //un pas vers le bas sur la diagonale droite
				}
				
			}	 
		
		if( this.currentPlayer == this.p1 ) { this.currentPlayer = this.p2; }
		else { this.currentPlayer = this.p1; }
			
		State etat = new State(this.p1,this.p2);
		etat.currentPlayer = this.currentPlayer;
		for(int i=0 ; i<7 ; i++) {
			for(int j=0 ; j<7 ; j++) {
				etat.grille[i][j] = this.grille[i][j];
			}
		}
		
		this.listEtats.add(etat);
		
		return etat;
	}
	
// METHODES AJOUTEES
	
// Affichage d'un état du jeu	
	@Override
	public String toString() {
		String str = new String();
		str = "\n  0 1 2 3 4 5 6\n";
		for (int i=0 ; i<7 ; i++) {
			str += (i) + " ";
			for (int j=0 ; j<7 ; j++) {
				if (this.grille[i][j] == this.p1)
				{
					str += "X ";
				}
				else if (this.grille[i][j] == this.p2)
				{
					str += "O ";
				}
				else
				{
					str += ".";
				}
		    }
			str += System.lineSeparator();
		}

		System.out.println(str);
		
		if(this.isOver() != true)
		{
			System.out.println("C'est à " + this.currentPlayer + " de jouer.");
			
			if(this.getMove(this.currentPlayer).size() != 0)
			{
				System.out.println("Coups valides: ");
				for (int i=0; i < this.getMove(this.currentPlayer).size() ; i++) {
				Move move = this.getMove(this.currentPlayer).get(i);
				System.out.print(move.toString());
				}
			}
			else System.out.println("Veuillez passer votre tour!");
		}
		return " ";
	}

// GETTERS ET SETTERS

	public Player getP1() {
		return this.p1;
	}

	public Player getP2() {
		return this.p2;
	}

	public Player getCurrentPlayer() {
		return this.currentPlayer;
	}
	
	public Player[][] getGrille() {
		return this.grille;
	}

	public void setP1(Player p1) {
		this.p1 = p1;
	}

	public void setP2(Player p2) {
		this.p2 = p2;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}
	
}
