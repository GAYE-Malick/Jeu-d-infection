package infection;

public class AlphaBeta {

	private Player p;
	private int prof;
	private static int cpt;
	
	public AlphaBeta(Player p, int prof) {
		this.p = p;
		this.prof = prof;
	}
	
	public double eval(State jeu, double a, double b, int prof)
	{
		if( (prof == 0) || (jeu.isOver()) )
		{
			if(jeu.getCurrentPlayer() == this.p)
			{
				return jeu.getScore(this.p);
			}
			else
			{
				return -jeu.getScore(this.p);
			}
		}
		else
		{
			cpt++;
			State s;
				
				for(int i=0 ; i < jeu.getMove(this.p).size() ; i++)
				{
					s = jeu.play(jeu.getMove(this.p).get(i));
					a = Math.max(a, -eval(s,-b,-a,prof-1));
					if( a>= b) return a;
				}
				
			return a;		
		}
	}
	
	public Move getBestMove(State jeu) {
		Move move = null;
		double bestVal = Double.NEGATIVE_INFINITY;
		double val, a = Double.NEGATIVE_INFINITY, b = Double.POSITIVE_INFINITY;
		State nextState;
		
		for(int i=0 ; i < jeu.getMove(this.p).size() ; i++)
		{
			nextState = jeu.play( jeu.getMove(this.p).get(i) );
			val = this.eval(nextState, a, b, this.prof);
			
			if(val > bestVal)
			{
				bestVal = val;
				if(i < jeu.getMove(this.p).size())
				move = jeu.getMove(this.p).get(i);
			}
		}
		
		return move;
	}

	public int getCpt() {
		return this.cpt;
	}
	
}
