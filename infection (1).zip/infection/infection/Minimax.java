package infection;

public class Minimax {

	private Player p;
	private int prof;
	private static int cpt;
	
	public Minimax(Player p, int prof) {
		this.p = p;
		this.prof = prof;
	}
	
	public double eval(State jeu, int prof)
	{
		if( (prof == 0) || (jeu.isOver()) )
		{
			return jeu.getScore(this.p);
		}
		else
		{
			cpt++;
			double b;
			if(jeu.getCurrentPlayer() == this.p)
			{
				b = Double.NEGATIVE_INFINITY;
				State s;
				
				for(int i=0 ; i < jeu.getMove(this.p).size() ; i++)
				{
					s = jeu.play(jeu.getMove(this.p).get(i));
					double m = eval(s, prof-1);
					if( b < m ) b = m;
				}
			}
			else
			{
				b = Double.POSITIVE_INFINITY;
				State s;
				
				for(int i=0 ; i < jeu.getMove(this.p).size() ; i++)
				{
					s = jeu.play(jeu.getMove(this.p).get(i));
					double m = eval(s, prof-1);
					if( b > m ) b = m;
				}
			}
			
			return b;
		}
	}
	
	public Move getBestMove(State jeu) {
		Move move = null;
		double bestVal = Double.NEGATIVE_INFINITY;
		double val;
		State nextState;
		
		for(int i=0 ; i < jeu.getMove(this.p).size() ; i++)
		{
			nextState = jeu.play( jeu.getMove(this.p).get(i) );
			val = this.eval(nextState, this.prof);
			
			if(val > bestVal)
			{
				bestVal = val;
				if(i < jeu.getMove(this.p).size())
				move = jeu.getMove(this.p).get(i);
			}
		}
		
		return move;
	}
	
	public int getCpt() {
		return this.cpt;
	}
	
}
