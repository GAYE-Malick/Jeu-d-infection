package infection;

public class Player {
	
	private String name;
	private int prof;

	public Player(String name, int prof) {
		this.name = name;
		this.prof = prof;
	}

	
//Méthode redéfinie toString()	
	@Override
	public String toString()
	{
		return this.name;
	}	
	
//GETTERS ET SETTERS	
	public String getName() {
		return this.name;
	}

	public int getProf() {
		return this.prof;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setProf(int prof) {
		this.prof = prof;
	}
	
}
